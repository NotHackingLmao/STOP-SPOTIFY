#pragma once
#include "stdafx.h"

DWORD WINAPI KillBanner (LPVOID);